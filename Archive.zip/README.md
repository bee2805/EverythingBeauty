# EverythingBeauty
This web application allows you to search make up products filtered through brands or product type. You'll also be able to see the price of the product.
